

    console.log('BITMIS ISLER',Evhanimi.bitmisIsleriBul());
    console.log('BITMEMIS ISLER',Evhanimi.bitmemisIsleriBul());
    console.log('BUTUN ISLER BITTI',Evhanimi.butunIslerBitir());
    console.log('İslerin Hepsi bitti mi', Evhanimi.islerBittiMi());