
 
function daire(yaricap){
    let Alan =Math.round(Math.PI*Math.pow(yaricap,2));
    return Alan;
    }
    
    
function dikdörtgenAlani(KisaKenar,UzunKenar){
    let dAlan = KisaKenar*UzunKenar;
    return dAlan;
    }
    
    
function dairecevre(r){
    let cevre = Math.round(2*Math.PI*r);
    return cevre;
    }
    
    
function dikdörtgenCevresi(KisaKenar,UzunKenar){
    let cevre = 2*(KisaKenar + UzunKenar);
    return cevre;
    }
    
    
function Küp(kenar){
    let hacim = Math.pow(kenar,3);
    return hacim;
    }
    
    
function Küpa(knr){
    let alan = 6*Math.pow(knr,2);
    return alan;
    }
