


function output(data){
    let result = document.getElementById("result"); // DOM API
    result.innerHTML += data;
}