let dairealani=hesaplama.daire(5);
    console.log(dairealani); 

let dln = hesaplama.dikdörtgenAlani(5,7);
    console.log(dln);

let drc = hesaplama.dairecevre(6);
    console.log(drc);

let dikcevre = hesaplama.dikdörtgenCevresi(4,8);
    console.log(dikcevre);

let küphacmi = hesaplama.Küp(3);
    console.log(küphacmi);

let küpalani = hesaplama.Küpa(5);
    console.log(küpalani);

