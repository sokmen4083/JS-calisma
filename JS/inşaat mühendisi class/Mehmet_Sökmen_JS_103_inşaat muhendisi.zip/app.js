let dairealani=daire(5);
    console.log(dairealani); 

let dln = dikdörtgenAlani(5,7);
    console.log(dln);

let drc = dairecevre(6);
    console.log(drc);

let dikcevre = dikdörtgenCevresi(4,8);
    console.log(dikcevre);

let küphacmi = Küp(3);
    console.log(küphacmi);

let küpalani = Küpa(5);
    console.log(küpalani);

